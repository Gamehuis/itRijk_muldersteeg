setTimeout(function() {
  var msr = document.title
  alert("AmberMode : " + msr)
}, 1000);